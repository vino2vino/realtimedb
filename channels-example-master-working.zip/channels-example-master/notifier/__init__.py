default_app_config = 'notifier.apps.NotifierConfig'
